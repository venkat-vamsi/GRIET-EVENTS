package com.example.cap06backend.cap06backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cap06BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
