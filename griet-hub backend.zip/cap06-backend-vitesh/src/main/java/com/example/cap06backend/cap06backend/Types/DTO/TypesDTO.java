package com.example.cap06backend.cap06backend.Types.DTO;

public record TypesDTO(
        Long typeId,
        String name,
        String email,
        String phone
) {
}
