package com.example.cap06backend.cap06backend.Clubs.DTO;

public record ClubsDTO(
        Long clubId,
        String clubName,
        String clubDescription,
        String clubContact
) {
}
