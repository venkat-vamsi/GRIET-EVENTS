package com.example.cap06backend.cap06backend.Venues.DTO;

public record VenuesDTO(
        Long venueId,
        String venueName
) {
}
