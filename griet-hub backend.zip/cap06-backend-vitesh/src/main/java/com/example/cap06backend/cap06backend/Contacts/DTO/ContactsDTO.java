package com.example.cap06backend.cap06backend.Contacts.DTO;

public record ContactsDTO(
        Long contactId,
        String name,
        String email,
        String phone
) {
}
